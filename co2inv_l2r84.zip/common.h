      common /debug/ dumpmats,dumpgreens,concheck,doinfluence,dumpgroups,dodiff, &
                     dosvd,doref,useoldgreens, commentary,do_extend 

      logical dumpmats,    & ! flag to set dumping of inversion matrices
              dumpgreens,  & ! flag to set dumping of Green's functions
              concheck,    & ! flag to check condition number
              doinfluence, & ! flag to turn on influence checking (see influence.f)
              doref,       & ! flag to do reference + difference calculation
              dodiff,      & ! flag to do differential form
              dosvd,       & ! do a singular value decomposition of frechet
              useoldgreens,& ! grab copy from previous GF dump
              do_extend,   & ! use old sources to build extended data
              commentary,  & ! spit out useful information along the way
              dumpgroups     ! flag to check whether to dump groups

      common /covinf/ srcdiag,datdiag

      logical srcdiag,     & ! is the src prior covariance diagonal?
              datdiag        ! is the prior data covariance diagonal?

! rml additions 29/9/00

      logical tc3steady
      logical pseudodata
      logical tc3tdi

! there's a pointer which can't be local and can't be in pointer.h, put
! it here.

!     real, dimension(:,:), pointer             ::  dvar ! data variance
!     common /dvar/ dvar


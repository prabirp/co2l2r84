! declaration of allocatable arrays

! This header file should only be included by routines which need to
! know the pointer syntax i.e allocation routines and probably the main
! program.

! If we move away from on the fly allocation, it should be sufficient to
! change the pointers here to arrays of sufficient size and cancel the
! allocation routine (he says hopefully).

! F90 version 98/11/09

! source arrays

      integer, dimension(:), allocatable :: srcyr    ! year of source
      integer, dimension(:), allocatable :: srcmnth  ! month of source
      integer, dimension(:), allocatable :: srcind   ! index into source array
      integer, dimension(:), allocatable :: greenind ! index into GF arrays
      integer, dimension(:), allocatable :: srctype  ! types of source

      real,    dimension(:), allocatable :: csrc     ! sources
      real,    dimension(:), allocatable :: src      ! unknown sources

      character(len=80), dimension(:), allocatable :: srcnm ! names of sources

! data stuff

      integer, dimension(:), allocatable :: dattype  ! data type
      integer, dimension(:), allocatable :: datav    ! data averaging length
      integer, dimension(:), allocatable :: datind   ! index into data arrays
      integer, dimension(:), allocatable :: datyr    ! year of data
      integer, dimension(:), allocatable :: datmnth  ! month of data
      integer, dimension(:), allocatable :: siteindex 

      real,    dimension(:), allocatable :: dat      ! data vector
      real,    dimension(:), allocatable :: datcopy  ! copy of data
      real,    dimension(:), allocatable :: cdat     ! data covariance
      real,    dimension(:), allocatable :: datlat   ! data latitudes
      real,    dimension(:), allocatable :: datlon   ! data longitudes

      character(len=80), dimension(:), allocatable :: datnm   ! data names

! group stuff

      integer, dimension(:),   allocatable ::  grouplen ! sources per group
      integer, dimension(:,:), allocatable ::  grouplst ! list of sources in groups

      character(len=80), dimension(:), allocatable :: groupnm ! group names

! miscellaneous stuff

      real, dimension(:,:),   allocatable ::  frech  ! Jacobian matrix
      real, dimension(:,:,:,:), allocatable:: greens ! Green's functions

      character(len=80), dimension(:), allocatable ::  constnm ! names of constraints

! some data sizes for allocation

      integer realsz     ! size of real in bytes
      parameter(realsz=4)
      integer intsz      ! size of integer in bytes
      parameter(intsz=4)
      integer logsz
      parameter(logsz=4) ! I hope!

! trying to define null pointer, horror!

      integer null
      parameter(null=0)
      integer stringlen         ! default length of all strings
      parameter(stringlen=80)   ! 80 still hardcoded lots of places
      integer inunit, outunit   ! temporary open units
      parameter(inunit=10, outunit=11)

! default unit numbers

      integer, parameter :: stdin=5,stdout=6, stderr=0

! Specifying unit numbers (dumpunit,mstunit,sbunit) the max no. of 
! formatted numbers/line in output (maxperline), and the no. of max
! words per line for splitting (maxwords).

      integer, parameter :: dumpunit=39,mstunit=40,sbunit=41,maxperline=7,maxwords=10

      character*4 monthnm(0:12)

      data monthnm /'-ann','-jan','-feb','-mar','-apr','-may','-jun','-jul','-aug','-sep','-oct','-nov','-dec'/

      integer maxtypes              ! max number of source or data types
      parameter(maxtypes=30)
      integer maxcorlen             ! maximum length of group for correlation
      parameter(maxcorlen=20)
      integer everyyear             ! special year meaning every year, * too hard
      parameter(everyyear=9999)
      integer linearsource          ! for a source increasing over time
      parameter(linearsource=-99)

      integer pointsperyear         ! potential number of datapoints in a year
!     parameter(pointsperyear=2190) ! six  per day
      parameter(pointsperyear=12)   ! once per month

!  rml 29/9/00

      integer, parameter   ::  monperyr=12
